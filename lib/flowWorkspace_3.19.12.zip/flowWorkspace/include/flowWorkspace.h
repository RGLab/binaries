
#ifndef __flowWorkspace_h__
#define __flowWorkspace_h__

#include "../../src/include/GatingSet.hpp"

#endif // __flowWorkspace_h__
